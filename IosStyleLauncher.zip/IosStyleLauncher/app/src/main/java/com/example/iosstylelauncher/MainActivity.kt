package com.example.iosstylelauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : Activity() {

    private lateinit var allApps: List<AppItem>
    private lateinit var dots: LinearLayout
    private var pageCount = 0

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        allApps = loadApps()
        val dockApps = allApps.take(4)
        val homePages = allApps.drop(4).chunked(24)
        pageCount = homePages.size + 1 // + App Library

        val root = FrameLayout(this)
        root.setPadding(0, dp(40), 0, dp(16))

        val pager = ViewPager2(this)
        pager.adapter = PagerAdapter(homePages, allApps)
        root.addView(pager, FrameLayout.LayoutParams(-1, -1).apply { bottomMargin = dp(150) })

        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        root.addView(dots, FrameLayout.LayoutParams(-1, dp(20)).apply {
            gravity = Gravity.BOTTOM; bottomMargin = dp(125)
        })
        updateDots(0)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateDots(position)
        })

        val dock = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = AppAdapter(dockApps, showLabel = false)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#55FFFFFF")); cornerRadius = dp(32).toFloat()
            }
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        root.addView(dock, FrameLayout.LayoutParams(-1, dp(100)).apply {
            gravity = Gravity.BOTTOM; leftMargin = dp(12); rightMargin = dp(12)
        })
        setContentView(root)
    }

    private fun updateDots(selected: Int) {
        dots.removeAllViews()
        for (i in 0 until pageCount) {
            val d = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == selected) Color.WHITE else Color.parseColor("#88FFFFFF"))
                }
            }
            dots.addView(d, LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    override fun onBackPressed() { /* a launcher ignores Back */ }

    // ---------- Adapters ----------

    inner class AppAdapter(
        private var items: List<AppItem>,
        private val showLabel: Boolean = true
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        fun submit(list: List<AppItem>) { items = list; notifyDataSetChanged() }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val col = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
                layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            val icon = ImageView(parent.context).apply {
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) =
                        o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat())
                }
                clipToOutline = true
            }
            col.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58)))
            val label = TextView(parent.context).apply {
                setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
                gravity = Gravity.CENTER
                setShadowLayer(3f, 0f, 1f, Color.BLACK)
                visibility = if (showLabel) View.VISIBLE else View.GONE
            }
            col.addView(label, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            return object : RecyclerView.ViewHolder(col) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val item = items[pos]
            val col = h.itemView as LinearLayout
            (col.getChildAt(0) as ImageView).setImageDrawable(item.icon)
            (col.getChildAt(1) as TextView).text = item.label
            col.setOnClickListener {
                packageManager.getLaunchIntentForPackage(item.pkg)?.let { startActivity(it) }
            }
        }

        override fun getItemCount() = items.size
    }

    inner class PagerAdapter(
        private val pages: List<List<AppItem>>,
        private val all: List<AppItem>
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun getItemViewType(position: Int) = if (position < pages.size) 0 else 1
        override fun getItemCount() = pages.size + 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val ctx = parent.context
            val lp = ViewGroup.LayoutParams(-1, -1)
            val grid = RecyclerView(ctx).apply {
                layoutManager = GridLayoutManager(ctx, 4)
                layoutParams = lp
            }
            if (viewType == 0) {
                grid.setPadding(dp(12), 0, dp(12), 0)
                return object : RecyclerView.ViewHolder(grid) {}
            }
            // App Library page: search bar + all apps
            val page = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; layoutParams = lp }
            val search = EditText(ctx).apply {
                hint = "App Library"; setHintTextColor(Color.parseColor("#CCFFFFFF"))
                setTextColor(Color.WHITE); isSingleLine = true
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#55FFFFFF")); cornerRadius = dp(14).toFloat()
                }
            }
            page.addView(search, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(dp(16), dp(8), dp(16), dp(8))
            })
            val adapter = AppAdapter(all)
            grid.adapter = adapter
            grid.setPadding(dp(12), 0, dp(12), 0)
            page.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
            search.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = s.toString().trim().lowercase()
                    adapter.submit(if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) })
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            return object : RecyclerView.ViewHolder(page) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            if (position < pages.size) {
                ((h.itemView) as RecyclerView).adapter = AppAdapter(pages[position])
            }
        }
    }
}
